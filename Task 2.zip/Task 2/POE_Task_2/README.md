# POE_Task_2
Changes made to assignment 2
 Closest method added into task to in melee units class
 Added conflict method to both ranged,melee and wizzard classes
 Changed conflict range from void to bool on units classes
 Added conflict range to ranged units and melee
 Added in generation of units: Ranged and melee
