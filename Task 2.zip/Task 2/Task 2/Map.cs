﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace Task_2
{
    public class Map
    {
        List<Units> rangedunits = new List<Units>();
        List<Units> meleeunits = new List<Units>();
        List<Buildings> factorybuilding = new List<Buildings>();
        List<Units> units;
        Random r = new Random();
        int unitNumbers;
        TextBox txtInfo;

        public List<Units> Units
        {
            get { return units; }
            set { units = value; }
        }

        public Map(int n, TextBox txt)
        {
            units = new List<Units>();
            unitNumbers = n;
            txtInfo = txt;
        }

        public void GenerateUnits()
        {
            for (int i = 0; i < unitNumbers; i++)
            {
                Melee r = new Melee(10, 10, 100, 50, 80, 200, "M", "@", true); //Assigning values to melee unit


                meleeunits.Add(r);
            }
            for (int j = 0; j < unitNumbers; j++)
            {
                Ranged_Unit ru = new Ranged_Unit(20, 20, 100, 200, 90, 150, "R", "^", true);//Creating a new renged unit. Adding values to ranged unit


                rangedunits.Add(ru);//Knows what to add to the list

            }

            for(int b = 0; b < unitNumbers; b++)
            {
                Factory_Building fb = new Factory_Building(25, 25, 200,5,"$");


            }
        }

        

        public void Display(GroupBox gbxBox)
        {
            gbxBox.Controls.Clear();

            foreach (Ranged_Unit ru in rangedunits)
            {
                Label lblRange = new Label();
                lblRange.Width = 200;
                lblRange.Height = 200;
                lblRange.Location = new Point(ru.xPos * 20, ru.yPos * 20);
                lblRange.Text = ru.symbol;

                gbxBox.Controls.Add(lblRange);
            }

            foreach (Melee m in meleeunits)
            {
                Label lblMelee = new Label();
                lblMelee.Width = 200;
                lblMelee.Height = 200;
                lblMelee.Location = new Point(m.xPos * 20, m.yPos * 20);//How much the positions change
                lblMelee.Text = m.symbol;

                gbxBox.Controls.Add(lblMelee);
            }

            foreach (Factory_Building fb in factorybuilding)
            {
                Label lblFactory = new Label();
                lblFactory.Width = 250;
                lblFactory.Height = 250;
                lblFactory.Location = new Point(fb.XPos * 40, fb.YPos * 40);
                lblFactory.Text = fb.Symbol;
            }

        }
            public void Unit_Click(object sender, EventArgs e)
            {
                int x, y;
                Button b = (Button)sender;
                x = b.Location.X / 20;
                y = b.Location.Y / 20;
                foreach (Units u in units)
                {
                    if (u is Ranged_Unit)
                    {
                        Ranged_Unit ru = (Ranged_Unit)u;
                        if (ru.xPos == x && ru.yPos == y)
                        {
                            txtInfo.Text = "";
                            txtInfo.Text = ru.ToString();
                        }
                    }
                    else if (u is Melee)
                    {
                        Melee mu = (Melee)u;
                        if (mu.xPos == x && mu.yPos == y)
                        {
                            txtInfo.Text = "";
                            txtInfo.Text = mu.ToString();
                        }
                    }

                }
            }
    }
}





